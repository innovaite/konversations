<?php
/**
 * Plugin Name: KonversAItions Content Preview
 * Description: Serves the updated raw HTML for the home page (/) and exit page (/exit/), overriding the prior raw-HTML plugin. Also exposes /home-preview/ and /exit-preview/ as backups.
 * Version: 1.1
 * Author: KonversAItions
 */

if (!defined('ABSPATH')) { exit; }

add_action('init', function () {
    $uri  = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $path = trim((string) parse_url($uri, PHP_URL_PATH), '/');

    if ($path === '' || $path === 'home-preview') {
        $file = plugin_dir_path(__FILE__) . 'home.html';
    } elseif ($path === 'exit' || $path === 'exit-preview') {
        $file = plugin_dir_path(__FILE__) . 'exit.html';
    } else {
        return;
    }

    if (!file_exists($file)) { return; }

    status_header(200);
    nocache_headers();
    header('Content-Type: text/html; charset=UTF-8');
    readfile($file);
    exit;
}, 0);
